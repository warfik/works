package com.telran;

public interface ConcatTextInterface {
    String concatenate(String[] texts);
}